 # Online Banking System ( Console Based Application )


<br>

The online baking system connected with MySQL to perform crud operation. It is a console base application.
This project is developed by me during construct week of Masai School.

# Tech Stack
- Core Java
- JDBC
- MySQL

# Modules
1. Admin Login 
2. Customer Login 
3. New Customer ? Register here
4. Forget Id / Password

# Features
- Customer Features:
- 1.Balance
- 2.Transactions
- 3.View last 10 Transactions
- 4.View account statements online
- 5.Account-to-Account transfer


- Admin Features:
- 1.View customer details with account number or cutomer id or mobile number
- 2.Update customer details 
- 3.close customer account 
- 4.View all customer of bank 


